package ast;

public enum Type
{
    NUMBER, STRING;
}
